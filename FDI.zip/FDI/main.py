from game import *
Game()
