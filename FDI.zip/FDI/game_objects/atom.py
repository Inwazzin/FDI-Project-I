from imports import *

class Atom(object):
    def __init__(self,
                 radius: object = 50,
                 color: object = (255, 255, 255),
                 pos: object = (0.0, 0.0),
                 velocity: object = (0.0, 0.0),
                 local_angle: object = 0,
                 mass: object = 1) -> object:
        print("Debug Create Atom:", radius, color, pos, velocity, local_angle, mass)

        self.color: pg.Color = pg.Color(*color)

        # Scalars
        self.radius: float = radius
        self.mass: int = mass
        self.local_angle: float = local_angle

        # Vectors
        self.pos: pg.Vector2 = pg.Vector2(pos)
        self.velocity: pg.Vector2 = pg.Vector2(velocity)

    def update(self, global_angle):
        # Maciej(metody) i Ania(czas)
        pass
    # a ja bede biadloc po polsku - Maciek
    def wektor_zderzenia(self, other): #dwie kulki - zwraca wektor miedzy nimi
        wek = pg.Vector2()
        wek.x = other.pos.x - self.pos.x
        wek.y = other.pos.y - self.pos.y
        return wek

    def oblicz_cos(self, wektor): #kulka i wektor miedzy kulkami -> kat miedzy predkoscia a wektorem
        cos = (wektor.x * self.velocity.x + wektor.y * self.velocity.y)/(mh.sqrt(self.velocity.x**2 + self.velocity.y**2) + mh.sqrt(wektor.x**2 + wektor.y**2))
        return cos

    def oblicz_nowe_predkosci_zderzenie_kulek(self, other): #tutaj chyba nie trzeba tlumaczyc za wiele
        wektor = self.wektor_zderzenia(other)
        cos1 = self.oblicz_cos(wektor) #cos dla self
        cos2 = other.oblicz_cos(wektor) #cos dla other
            #obliczenia
        sel_vel_prost = self.velocity * cos1
        sel_vel_row = self.velocity * mh.sqrt(1-cos1**2)
        oth_vel_prost = other.velocity * cos2
        oth_vel_row = other.velocity * mh.sqrt(1 - cos2**2)
            #podstawienie wynikow
        self.velocity = sel_vel_prost + oth_vel_row
        other.velocity =oth_vel_prost + sel_vel_row

    def oblicz_nowe_predkosci_zderzenie_sciana(self, wariant): #wariant - znak wielka litera, czy od North, South, etc...
        if wariant == 'N' or wariant == 'S':
            self.velocity.y *= -1
        else:
            self.velocity.x *= -1

    def render(self, screen: pg.Surface):
        gfxdraw.aacircle(screen, int(self.pos.x), int(self.pos.y), int(self.radius), self.color)
        gfxdraw.filled_circle(screen, int(self.pos.x), int(self.pos.y), int(self.radius), self.color)
